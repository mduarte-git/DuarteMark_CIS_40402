/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Markd
 *
 * Created on March 3, 2020, 7:24 PM
 */

#include <iostream>

//executables begin here

using namespace std;

int main(){
    //Declare Variable Data Types and Constants
    double meal= 44.50; //Meal cost
    double tax= .0675*meal; //Tax cost
    double tip= (meal+tax)*.15; //Tip cost
    double total= meal+tax+tip; //Total cost
    
    //Displaying the amounts specified
    cout<<"The meal costs: $"<<meal<<endl;
    cout<<"The tax is: $"<<tax<<endl;
    cout<<"The tip is: $"<<tip<<endl;
    cout<<"The total cost is: $"<<total<<endl<<endl;
           
    return 0;
}
    
    

