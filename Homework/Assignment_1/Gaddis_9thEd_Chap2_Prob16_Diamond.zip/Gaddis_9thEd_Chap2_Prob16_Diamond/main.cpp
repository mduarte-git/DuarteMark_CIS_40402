/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Markd
 *
 * Created on March 3, 2020, 8:39 PM
 */

#include <iostream>

using namespace std;

int main(){
    
    cout<<"   *\n"
            <<"  ***\n"
            <<" *****\n"
            <<"*******\n"
            <<" *****\n"
            <<"  ***\n"
            <<"   *\n";
            
    return 0;
}