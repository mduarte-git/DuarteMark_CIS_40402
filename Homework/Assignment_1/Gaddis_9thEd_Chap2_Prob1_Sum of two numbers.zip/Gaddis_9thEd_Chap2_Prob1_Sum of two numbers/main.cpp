/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Markd
 *
 * Created on March 3, 2020, 8:04 PM
 */

#include <iostream>

using namespace std;

main(){
    
    int a=50;   //value is 50
    int b=100;  //value is 100
    int c=a+b;  //value is total
    
    //display the answer
    cout<< "The sum of "<<a<<"+"<<b<<"="<<c<<endl;
    return 0;
}

