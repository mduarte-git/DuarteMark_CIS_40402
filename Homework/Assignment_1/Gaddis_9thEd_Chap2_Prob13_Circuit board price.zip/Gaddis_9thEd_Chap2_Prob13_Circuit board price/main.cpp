/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Markd
 *
 * Created on March 3, 2020, 11:02 PM
 */

#include <iostream>

using namespace std;

int main(){
    double basePrice = 14.95;
    double sellPrice = (basePrice * 0.35) + basePrice;

    cout << "The selling price of a circuit board is: $"
    << sellPrice << endl << endl;
    
    return 0;

}

