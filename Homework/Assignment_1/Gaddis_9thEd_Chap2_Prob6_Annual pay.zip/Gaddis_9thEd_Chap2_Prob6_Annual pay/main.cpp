/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Markd
 *
 * Created on March 3, 2020, 9:12 PM
 */

#include <iostream>

using namespace std;

int main(){
    double payAmount = 2200.00;
    double payPeriods = 26;
    double annualPay = payAmount * payPeriods;

    cout << "The employee earns $" << payAmount << " each pay period. \n";
    cout << "There are " << payPeriods << " pay periods in a year. \n";
    cout << "The annual pay is: $" << annualPay << endl << endl;
    
    return 0;

}
