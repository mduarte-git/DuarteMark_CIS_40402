/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Markd
 *
 * Created on March 3, 2020, 8:56 PM
 */

#include <iostream>

using namespace std;

int main(){
    
    double acre= 43560; //how many sqr ft in an acre
    double land= 391876; //the land given
    double conversion= land/acre;//the conversion
    
    cout<<land<<" sqr ft = "<<conversion<<" acres"<<endl;
    
    return 0;
}
