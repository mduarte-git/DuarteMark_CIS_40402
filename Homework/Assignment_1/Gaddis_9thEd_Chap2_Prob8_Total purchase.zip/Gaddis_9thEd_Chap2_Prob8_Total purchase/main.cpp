/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Markd
 *
 * Created on March 3, 2020, 8:24 PM
 */

#include <iostream>

using namespace std;

int main(){
    double item1= 15.95; //Price of item 1 = $15.95
    double item2= 24.95; //Price of item 2 = $24.95
    double item3= 6.90; //Price of item 3 = $6.95
    double item4= 12.95; //Price of item 4 = $12.95
    double item5= 3.95;//Price of item 5 = $3.95
    double subtotal= item1+item2+item3+item4+item5; //subtotal
    double tax= (item1+item2+item3+item4+item5)*.07; //sales tax
    
    cout<<"The subtotal of the purchase is $"<<subtotal<<endl<<"The sales tax is $"<<tax<<endl<<"The total is $"<<subtotal+tax<<endl;
    
    return 0;
}
