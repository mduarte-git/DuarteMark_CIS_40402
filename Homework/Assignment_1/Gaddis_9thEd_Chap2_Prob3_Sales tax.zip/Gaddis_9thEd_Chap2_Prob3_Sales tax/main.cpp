/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Markd
 *
 * Created on March 3, 2020, 8:15 PM
 */

#include <iostream>

using namespace std;

int main(){
    double cost= 95;
    double sstax= cost*.04;
    double cstax= cost*.02;
    double ttax= sstax+cstax;
    
    cout<<"The total tax of $"<<cost<<" is $"<<ttax<<endl;
    
    return 0;
}


